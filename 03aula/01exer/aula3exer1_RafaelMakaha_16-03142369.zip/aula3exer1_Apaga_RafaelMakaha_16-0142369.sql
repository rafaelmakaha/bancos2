/*
-- --------            << exer01aula03 >>        ------------ --
--                                                                   --
--                    SCRIPT APAGA (DDL)                             --
--                                                                   --
-- Data Criacao ..........: 30/09/2019                               --
-- Autor(es) .............: Rafael Makaha Gomes Ferreira            --
-- Banco de Dados ........: MySQL                                    --
-- Base de Dados(nome) ...: exer01aula03                      --
--                                                                   --
-- Data Ultima Alteracao ..: 30/09/2019                              --
--    + Deletando todas as tabelas uma por vez                       --
--                                                                   --
-- PROJETO => 1 Base de Dados                                        --
--         => 5 Tabelas                                              --
--                                                                   --
-- ----------------------------------------------------------------- --
*/

USE exer01aula03;

DROP TABLE possui;
DROP TABLE trabalha;
DROP TABLE ESPECIALIDADE;
DROP TABLE SEETOR;
DROP TABLE PLANTONISTA;