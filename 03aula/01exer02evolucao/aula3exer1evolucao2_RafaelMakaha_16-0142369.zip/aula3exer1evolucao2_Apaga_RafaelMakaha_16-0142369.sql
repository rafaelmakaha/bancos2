-- --------            << aula3exer1evolucao2 >>                 ------------ --
--                                                                   --
--                    SCRIPT APAGA (DDL)                             --
--                                                                   --
-- Data Criacao ..........: 02/10/2019                               --
-- Autor(es) .............: Daniel Maike Mendes Gonçalves            --
-- Banco de Dados ........: MySQL                                    --
-- Base de Dados(nome) ...: aula3exer1evolucao2                               --
--                                                                   --
-- Data Ultima Alteracao ..: 02/10/2019                              --
--    + Deletando todas as tabelas uma por vez                       --
--                                                                   --
-- PROJETO => 1 Base de Dados                                        --
--         => 5 Tabelas                                              --
--                                                                   --
-- ----------------------------------------------------------------- --

use aula3exer1evolucao2;

DROP TABLE possui;
DROP TABLE trabalha;
DROP TABLE ESPECIALIDADE;
DROP TABLE SETOR;
DROP TABLE PLANTONISTA;