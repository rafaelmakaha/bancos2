/*
-- --------            << aula4extra1 >>        ------------ --
--                                                                   --
--                    SCRIPT APAGA (DDL)                             --
--                                                                   --
-- Data Criacao ..........: 04/09/2019                               --
-- Autor(es) .............: Rafael Makaha Gomes Ferreira            --
-- Banco de Dados ........: MySQL                                    --
-- Base de Dados(nome) ...: aula4extra1                      --
--                                                                   --
-- Data Ultima Alteracao ..: 04/09/2019                              --
--    + Deletando todas as tabelas uma por vez                       --
--                                                                   --
-- PROJETO => 1 Base de Dados                                        --
--         => 2 Tabelas                                              --
--                                                                   --
-- ----------------------------------------------------------------- --
*/

use aula4extra1;

DROP TABLE CIDADE;
DROP TABLE ESTADO;