﻿/*
-- --------            << aula1exer2Evolucao4 >>        ------------ --
--                                                                   --
--                    SCRIPT APAGA (DDL)                             --
--                                                                   --
-- Data Criacao ..........: 10/09/2019                               --
-- Autor(es) .............: Rafael Makaha Gomes Ferreira            --
-- Banco de Dados ........: MySQL                                    --
-- Base de Dados(nome) ...: aula1exer2Evolucao4                      --
--                                                                   --
-- Data Ultima Alteracao ..: 10/09/2019                              --
--    + Deletando todas as tabelas uma por vez                       --
--                                                                   --
-- PROJETO => 1 Base de Dados                                        --
--         => 8 Tabelas                                              --
--                                                                   --
-- ----------------------------------------------------------------- --
*/

use aula1exer2Evolucao4;

DROP TABLE possui;
DROP TABLE telefone;
DROP TABLE VENDA;
DROP TABLE PRODUTO;
DROP TABLE AREA;
DROP TABLE GERENTE;
DROP TABLE EMPREGADO;
DROP TABLE PESSOA;