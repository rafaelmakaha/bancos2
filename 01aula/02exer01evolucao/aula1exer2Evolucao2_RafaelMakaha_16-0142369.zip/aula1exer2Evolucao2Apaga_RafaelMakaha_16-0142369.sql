-- --------               << aula1exer2evolucao2 >>              ------------ --
--                                                                   --
--                    SCRIPT DE REMOCAO (DDL)                        --
--                                                                   --
-- Data Criacao ..........: 21/08/2019                               --
-- Autor(es) .............: Rafael Makaha Gomes Ferreira             --
-- Banco de Dados ........: MySQL                                    --
-- Base de Dados(nome) ...: aula1exer2evolucao2                               --
--                                                                   --
-- Data Ultima Alteracao ..: 21/08/2019                              --
--                                                                   --
--                                                                   --
-- PROJETO => SCRIPT DE APAGAR TABELAS                               --
--                                                                   --
-- ----------------------------------------------------------------- --

USE aula1exer2evolucao2;

DROP TABLE compoe;
DROP TABLE gerencia;
DROP TABLE VENDA;
DROP TABLE PRODUTO;
DROP TABLE AREA;
DROP TABLE EMPREGADO;
DROP TABLE GERENTE;
DROP TABLE telefone;
