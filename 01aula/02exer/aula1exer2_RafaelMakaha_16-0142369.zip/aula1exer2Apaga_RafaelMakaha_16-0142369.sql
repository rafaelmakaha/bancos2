-- --------               << aula1exer2 >>              ------------ --
--                                                                   --
--                    SCRIPT DE REMOCAO (DDL)                        --
--                                                                   --
-- Data Criacao ..........: 19/08/2019                               --
-- Autor(es) .............: Rafael Makaha Gomes Ferreira             --
-- Banco de Dados ........: MySQL                                    --
-- Base de Dados(nome) ...: aula1exer2                               --
--                                                                   --
-- Data Ultima Alteracao ..: 19/08/2019                              --
--                                                                   --
--                                                                   --
-- PROJETO => SCRIPT DE APAGAR TABELAS                               --
--                                                                   --
-- ----------------------------------------------------------------- --

USE aula1exer2;

DROP TABLE ITEM;
DROP TABLE supervisiona;
DROP TABLE PRODUTO;
DROP TABLE VENDA;
DROP TABLE FUNCIONARIO;
DROP TABLE endereco;
DROP TABLE telefone;
DROP TABLE GERENTE;
DROP TABLE PESSOA;
